## Requirements

 - [ANT](https://ant.apache.org/manual/install.html)
 - [JAVA](https://www.oracle.com/technetwork/java/javaseproducts/downloads/index.html)

## Getting Started
Build an optimized version of your application to /build
```bash
ant build
```
