var clientChatUiSendNavigation = function (session, href, title) {
    session.sendNavigation(href, title);
};
