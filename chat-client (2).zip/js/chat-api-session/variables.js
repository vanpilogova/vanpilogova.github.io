var chatApiSessionVariables = {
    logging: false,
    textFormId: undefined
};
